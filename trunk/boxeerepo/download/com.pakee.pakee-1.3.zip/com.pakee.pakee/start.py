import mc

mc.GetApp().GetLocalConfig().SetValue("pakee_initial", 'True')
mc.ActivateWindow(14000)
